The .png files go into "Rogue-Like-1.6e-linux/game/images/DoreenSprite/" directory. Feel free to back up the existing files if you want, but they can replace whatever files are in there.


The .xcf is a GIMP (open source alternative to photoshop) file that I did the actual edits from and does NOT go into the game.